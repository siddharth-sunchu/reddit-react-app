export { default as PostsContainer } from './Posts/PostsContainer';
export { default as SearchBarContainer } from './SearchBar/SearchBarContainer';