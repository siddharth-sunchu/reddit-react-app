export { default as PostCard } from './PostCard/PostCard';
export { default as SearchButton } from '../components/SearchButton/SearchButton';
export { default as SearchInput } from './SearchInput/SearchInput';
export { default as PostCards } from './PostCards/PostCards';
export { default as Loader } from './Loader/Loader';
export { default as PageNav } from './PageNav/PageNav';

